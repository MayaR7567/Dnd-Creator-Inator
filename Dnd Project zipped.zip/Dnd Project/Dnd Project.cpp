// Dnd Project.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

//Initilizing global variables
ofstream MySheet("CharacterSheet.txt");
string armor;	//string to put armor word
string weapon;	//string to put weapon word
string proSkills[4] = {};	//blank array to store the chosen skill to be proficent with
int strMod;		//intger for strength modifier
int dexMod;		//intger for dexterity modifier
int conMod;		//intger for consistitution modifier
int intMod;		//intger for intelligence modifier
int wisMod;		//intger for wisdom modifier
int chaMod;		//intger for charisma modifier
int healthRoll;		//health value
int weaponNum = 0;	//selected weapon number
int armorNum = 0;	//selected armor number
int chosenSkill;	//number for selected skill to be proficent with
int avaliableSkills;	//numbers of skills availble to chosen from in the class
int choices;		//amount of skills that can be chosen in that class
int chosen = 0;		//amount of skills already pick, default 0
int play = 0;		//intger to indicate if user wants to play
int exitGame = 0;	//intger to exit game
int raceNum = 0;	//default value for race number
int classNum = 0;	//default value of class number
bool repeat = false;	//bool for if a skill has been chosen before
int skillValue[6] = { 0, 0, 0, 0, 0, 0 };	//default value of zero for skill number array
string skills[6] = { "Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma" };	//list of ability skills
string minorSkills[18]={ "Athletics","Acrobatics","Sleight of Hand","Stealth","Arcana", "History","Investigation","Nature","Religion","Animal Handling","Insight","Medicine","Perception","Survival","Deception","Intimidation","Performance","Persuasion" };
string classes[6] = { "Rogue", "Warlock", "Druid", "Bard", "Cleric", "Wizard" };	//list of all classes
string races[6] = { "Tiefling","Elf","Dwarf","Dragonborn","Human","Gnome" };		//list of all races
//FUNCTIONS
void readTwoLines(int first, int second, int third) {
	//function to display 2 lines of the DnDtext file, can input the 2 lines as parameters, thrid parameter determines which it prints too
	ifstream myfile("DDtext.txt");	//opens file
	string line;	//creates line string to hold value
	for (int i = 1; getline(myfile, line);) {	//loop to read throguh text
		if (i == first || i == second) {	//inputs the chosen lines
			if (third == 0) {
				cout << line << endl;	//prints in display
			}
			else if (third == 1) {
				MySheet << line << endl;	//prints in character sheet
			}
			
		}
		i++;
	}
}
void readOneLine(int first, int third) {
	//function to display 1 line of DnDtext file, can input the line as parameter, thrid parameter determines which it prints too
	ifstream myfile("DDtext.txt");	//opens file
	string line; //creates line to hold value
	for (int i = 1; getline(myfile, line);) {	//loop to read through text
		if (i == first) {	//select the line
			if (third == 0) {
				cout << line << endl;	//print to display
			}
			else if (third == 1) {
				MySheet << line << endl;	//print to character sheet
			}
		}
		i++;
	}
}
void displayDes(int begin, int end) {
	//function prints a section of DnDtext file
	ifstream myfile("DDtext.txt");		//opens text
	string line;
	for (int i = 1; getline(myfile, line);) {	//reads each line
		if (i >= begin && i <= end) {		//selects section
			cout << line << endl;
		}
		i++;
	}
}
void rollHealth(int diceValue) {
	//function to roll the health, input the max number they can roll
	int rollStatus = 0;
	while (rollStatus != 1) {
		//loops menu
		cout << "\nTime to roll your Health. You can roll a d" << diceValue << endl;
		cout << "1 - roll";
		cin >> rollStatus;
		if (rollStatus == 1) { //checks for correct value to break
			break;
		}
		else {
			//removes errored input
			cout << "Invalid Input\n" << endl;
			cin.clear();
			cin.ignore(150, '\n');
		}
	}
	healthRoll = rand() % diceValue + 1; //rolls random number
	cout << "Health: " << healthRoll << endl; //displays health
}
void spells() {
	//message about spells, in function for improve later
	cout << "\nSee DM for guide on spells" << endl;
}

//CLASSES
class Rogue {
public:
	void displayDes() {
		//method to display the description for DnDText file
		cout << "\nYou have chosen the Rogue class.\n"
			"You are:"<<endl;
		readOneLine(5,0);
	};
	void weaponList() {
		//method to select a weapon from this classes avaliable weapons
		//string of class weapons
		string rogueWeapons[9] = { "Club", "Dagger", "Quarterstaff", "Handaxe", "Spear", "Light Cross Bow", "Longsword", "Shortsword", "Raiper" };
		//loops menu until valid selection
		while (!(weaponNum ==1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7|| weaponNum == 8 || weaponNum == 9)){
			cout << "\nSelect a Weapon:" << endl;
			for (int i = 0; i < 9; i++) {	//loop to list weapons in array
				cout << i + 1 << "-" << rogueWeapons[i] << "\n";
			}
			cin >> weaponNum;	//asks for a the number of selected weapon
			//checks if matches an option
			if (weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8 || weaponNum == 9) {
				break;
			}
			else {	//gets rid of errors
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		//display chosen weaopn and store the name
		weapon = rogueWeapons[weaponNum - 1];
		cout << "Your weapon is a: " << weapon << endl;
	};
	void armorList() {
		//method to select armor from list for class
		//lists armor options
		string rogueArmor[2] = { "Light Armor", "No Armor"};
		//loop armor menu until valid choice
		while (!(armorNum == 1 || armorNum == 2)) {
			cout << "\nSelect Armor:" << endl;
			//displays list
			for (int i = 0; i < 2; i++) {
				cout << i + 1 << "-" << rogueArmor[i] << "\n";
			}
			cin >> armorNum;	//asks for input
			if (armorNum == 1 || armorNum == 2) {	//checks if valid option
				break;
			}
			else {	//gets rid of errors
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		armor = rogueArmor[armorNum - 1];	//stores armor name
		cout << "You have: " << armor << endl;	//displays armor choice

	};
	void skillList() {
		//method to choice what skills to be proficent with
		//each class has a different amount of choices and different amount of skills to choose from
		choices = 4;
		avaliableSkills = 11;
		//lists avaliable skills
		string rogueSkills[11] = {"Acrobatics", "Athletics", "Deception", "Insight", "Intimidation", "Investigation", "Perception", "Performance", "Persuasion", "Sleight of Hand","Stealth"};
		while (chosen < choices) {
			//loops menu until all are chosen
			chosenSkill = 0;	//resets chosenSkill to zero since most classes can choose multiple
			while (!(chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7 || chosenSkill == 8 || chosenSkill == 9 || chosenSkill == 10 || chosenSkill == 11)) {
				//loops selection menu until valid input
				cout << "\nChoose " << choices - chosen << " skill(s) to be proficent in:" << endl; //tells you how many skills left to choose
				for (int i = 0; i < avaliableSkills; i++) {	//displays skill list
					cout << i + 1 << "-" << rogueSkills[i] << "\n";
				}
				cin >> chosenSkill;	//asks for skill number
				//checks if valid option
				if (chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7 || chosenSkill == 8 || chosenSkill == 9 || chosenSkill == 10 || chosenSkill == 11) {
					break;
				}
				else {	//gets rid of errors
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			repeat = false;		//resets repeat status to false so the menu repeats
			for (int j = 0; j < 4; j++) {	//checks if the skill the user inputted has been selected before
				if (proSkills[j] == rogueSkills[chosenSkill - 1]) {
					cout << "You have already chosen " << rogueSkills[chosenSkill - 1];
					repeat = true;
					break;
				}
			}
			if (repeat == true) {	//if it is a repeat skill restarts selection
				continue;
			}
			else {	//assigns the chosen skill to an array to use later
				proSkills[chosen] = rogueSkills[chosenSkill - 1];
				chosen += 1;	//increases chosen variable 
			}
		}
		cout << "You are now proficent in:" << endl;	//displays choices
		for (int i = 0; i < choices; i++) {
			cout << proSkills[i] << endl;
		}
	}
	
};
class Warlock {
public:
	void displayDes() {
		cout << "\nYou have chosen the Warlock class.\n"
			"You are:" << endl;
		readOneLine(15,0);
	};
	void weaponList() {
		string warlockWeapons[5] = { "Club", "Dagger", "Quarterstaff", "Handaxe", "Spear" };
		while (!(weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5)) {
			cout << "\nSelect a Weapon:" << endl;
			for (int i = 0; i < 5; i++) {
				cout << i + 1 << "-" << warlockWeapons[i] << "\n";
			}
			cin >> weaponNum;
			if (weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}

		weapon = warlockWeapons[weaponNum - 1];
		cout << "Your weapon is a: " << weapon << endl;
	};
	void armorList() {
		string warlockArmor[2] = { "Light Armor", "No Armor" };
		while (!(armorNum == 1 || armorNum == 2)) {
			cout << "\nSelect Armor:" << endl;
			for (int i = 0; i < 2; i++) {
				cout << i + 1 << "-" << warlockArmor[i] << "\n";
			}
			cin >> armorNum;
			if (armorNum == 1 || armorNum == 2) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		armor = warlockArmor[armorNum - 1];
		cout << "You have: " << armor << endl;
	};
	void skillList() {
		avaliableSkills = 7;
		choices = 2;
		string warlockSkills[7] = { "Arcana", "Deception", "History", "Intimidation", "Investigation", "Nature", "Religion" };
		while (chosen < choices) {
			chosenSkill = 0;
			while (!(chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7)) {
				cout << "\nChoose " << choices - chosen << " skill(s) to be proficent in:" << endl;
				for (int i = 0; i < avaliableSkills; i++) {
					cout << i + 1 << "-" << warlockSkills[i] << "\n";
				}
				cin >> chosenSkill;
				if (chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7) {
					break;
				}
				else {
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			repeat = false;
			for (int j = 0; j < 4; j++) {
				if (proSkills[j] == warlockSkills[chosenSkill - 1]) {
					cout << "You have already chosen " << warlockSkills[chosenSkill - 1];
					repeat = true;
					break;
				}
			}
			if (repeat == true) {
				continue;
			}else{
				proSkills[chosen] = warlockSkills[chosenSkill - 1];
				chosen += 1;
			}

		}
		cout << "You are now proficent in:" << endl;
		for (int i = 0; i < choices; i++) {
			cout << proSkills[i] << endl;
		}
	}
};
class Druid {
public:
	void displayDes() {
		cout << "\nYou have chosen the Druid class.\n"
			"You are:" << endl;
		readOneLine(26,0);
	};
	void weaponList() {
		string druidWeapons[10] = { "Club", "Dagger", "Quarterstaff", "Handaxe", "Spear", "Scimitar", "Sickle", "Sling", "Mace", "Javelin" };
		while (!(weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8 || weaponNum == 9 || weaponNum == 10)) {
			cout << "\nSelect a Weapon:" << endl;
			for (int i = 0; i < 10; i++) {
				cout << i + 1 << "-" << druidWeapons[i] << "\n";
			}
			cin >> weaponNum;
			if (weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8 || weaponNum == 9 || weaponNum == 10) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		weapon = druidWeapons[weaponNum - 1];
		cout << "Your weapon is a: " << weapon << endl;
	};
	void armorList() {
		string druidArmor[4] = { "Light Armor", "Light Armor with Shield", "Medium Armor", "No Armor" };
		while (!(armorNum == 1 || armorNum == 2 || armorNum == 3 || armorNum == 4)) {
			cout << "\nSelect Armor:" << endl;
			for (int i = 0; i < 4; i++) {
				cout << i + 1 << "-" << druidArmor[i] << "\n";
			}
			cin >> armorNum;
			if (armorNum == 1 || armorNum == 2 || armorNum == 3 || armorNum == 4) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		armor = druidArmor[armorNum - 1];
		cout << "You have: " << armor << endl;

	};
	void skillList() {
		choices = 2;
		avaliableSkills = 8;
		string druidSkills[8] = {"Arcana", "Animal Handling", "Insight", "Medicine", "Nature", "Perception", "Religion","Survival" };
		while (chosen < choices) {
			chosenSkill = 0;
			while (!(chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7 || chosenSkill == 8)) {
				cout << "\nChoose " << choices - chosen << " skill(s) to be proficent in:" << endl;
				for (int i = 0; i < avaliableSkills; i++) {
					cout << i + 1 << "-" << druidSkills[i] << "\n";
				}
				cin >> chosenSkill;
				if (chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7 || chosenSkill == 8) {
					break;
				}
				else {
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			repeat = false;
			for (int j = 0; j < 4; j++) {
				if (proSkills[j] == druidSkills[chosenSkill - 1]) {
					cout << "You have already chosen " << druidSkills[chosenSkill - 1];
					repeat = true;
					break;
				}
			}
			if (repeat == true) {
				continue;
			}
			else {
				proSkills[chosen] = druidSkills[chosenSkill - 1];
				chosen += 1;
			}
		}
		cout << "You are now proficent in:" << endl;
		for (int i = 0; i < choices; i++) {
			cout << proSkills[i] << endl;
		}
	}
};
class Bard {
public:
	void displayDes() {
		cout << "\nYou have chosen the Bard class.\n"
			"You are:" << endl;
		readOneLine(37,0);
	};
	void weaponList() {
		string bardWeapons[9] = { "Club", "Dagger", "Quarterstaff", "Handaxe", "Spear", "Light Cross Bow", "Longsword", "Shortsword", "Raiper" };
		while (!(weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8 || weaponNum == 9)) {
			cout << "\nSelect a Weapon:" << endl;
			for (int i = 0; i < 9; i++) {
				cout << i + 1 << "-" << bardWeapons[i] << "\n";
			}
			cin >> weaponNum;
			if (weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8 || weaponNum == 9) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		weapon = bardWeapons[weaponNum - 1];
		cout << "Your weapon is a: " << weapon << endl;
	};
	void armorList() {
		string bardArmor[2] = { "Light Armor", "No Armor" };
		while (!(armorNum == 1 || armorNum == 2)) {
			cout << "\nSelect Armor:" << endl;
			for (int i = 0; i < 2; i++) {
				cout << i + 1 << "-" << bardArmor[i] << "\n";
			}
			cin >> armorNum;
			if (armorNum == 1 || armorNum == 2) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		armor = bardArmor[armorNum - 1];
		cout << "You have: " << armor << endl;
	};
	void skillList() {
		choices = 3;
		avaliableSkills = 18;
		string bardSkills[18] = {"Athletics","Acrobatics","Sleight of Hand","Stealth","Arcana", "History","Investigation","Nature","Religion","Animal Handling","Insight","Medicine","Perception","Survival","Deception","Intimidation","Performance","Persuasion" };
		while (chosen < choices) {
			chosenSkill = 0;
			while (!(chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7 || chosenSkill == 8 || chosenSkill == 9 || chosenSkill == 10 || chosenSkill == 11 || chosenSkill == 12 || chosenSkill == 13 || chosenSkill == 14 || chosenSkill == 15 || chosenSkill == 16 || chosenSkill == 17 || chosenSkill == 18)) {
				cout << "\nChoose " << choices - chosen << " skill(s) to be proficent in:" << endl;
				for (int i = 0; i < avaliableSkills; i++) {
					cout << i + 1 << "-" << bardSkills[i] << "\n";
				}
				cin >> chosenSkill;
				if (chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6 || chosenSkill == 7 || chosenSkill == 8 || chosenSkill == 9 || chosenSkill == 10 || chosenSkill == 11 || chosenSkill == 12 || chosenSkill == 13 || chosenSkill == 14 || chosenSkill == 15 || chosenSkill == 16 || chosenSkill == 17 || chosenSkill == 18) {
					break;
				}
				else {
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			repeat = false;
			for (int j = 0; j < 4; j++) {
				if (proSkills[j] == bardSkills[chosenSkill - 1]) {
					cout << "You have already chosen " << bardSkills[chosenSkill - 1];
					repeat = true;
					break;
				}
			}
			if (repeat == true) {
				continue;
			}
			else {
				proSkills[chosen] = bardSkills[chosenSkill - 1];
				chosen += 1;
			}
		}
		cout << "You are now proficent in:" << endl;
		for (int i = 0; i < choices; i++) {
			cout << proSkills[i] << endl;
		}
	}
};
class Cleric {
public:
	void displayDes() {
		cout << "\nYou have chosen the Cleric class.\n"
			"You are:" << endl;
		readOneLine(47,0);
	};
	void weaponList() {
		string clericWeapons[5] = { "Club", "Dagger", "Quarterstaff", "Handaxe", "Spear" };
		while (!(weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5)){
			cout << "\nSelect a Weapon:" << endl;
			for (int i = 0; i < 5; i++) {
				cout << i + 1 << "-" << clericWeapons[i] << "\n";
			}
			cin >> weaponNum;
			if (weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		weapon = clericWeapons[weaponNum - 1];
		cout << "Your weapon is a: " << weapon << endl;
	};
	void armorList() {
		string clericArmor[4] = { "Light Armor", "Light Armor with shield", "Medium Armor", "No Armor" };
		while (!(armorNum == 1 || armorNum == 2 || armorNum == 3 || armorNum == 4)) {
			cout << "\nSelect Armor:" << endl;
			for (int i = 0; i < 4; i++) {
				cout << i + 1 << "-" << clericArmor[i] << "\n";
			}
			cin >> armorNum;
			if (armorNum == 1 || armorNum == 2 || armorNum == 3 || armorNum == 4) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		armor = clericArmor[armorNum - 1];
		cout << "You have: " << armor << endl;
	};
	void skillList() {
		choices = 2;
		avaliableSkills = 5;
		string clericSkills[5] = {"History", "Insight", "Medicine", "Persuasion", "Religion" };
		while (chosen < choices) {
			chosenSkill = 0;
			while (!(chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5)) {
				cout << "\nChoose " << choices - chosen << " skill(s) to be proficent in:" << endl;
				for (int i = 0; i < avaliableSkills; i++) {
					cout << i + 1 << "-" << clericSkills[i] << "\n";
				}
				cin >> chosenSkill;
				if (chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5) {
					break;
				}
				else {
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			repeat = false;
			for (int j = 0; j < 4; j++) {
				if (proSkills[j] == clericSkills[chosenSkill - 1]) {
					cout << "You have already chosen " << clericSkills[chosenSkill - 1];
					repeat = true;
					break;
				}
			}
			if (repeat == true) {
				continue;
			}
			else {
				proSkills[chosen] = clericSkills[chosenSkill - 1];
				chosen += 1;
			}
		}
		cout << "You are now proficent in:" << endl;
		for (int i = 0; i < choices; i++) {
			cout << proSkills[i] << endl;
		}
	}
};
class Wizard {
public:
	void displayDes() {
		cout << "\nYou have chosen the Wizard class.\n"
			"You are:" << endl;
		readOneLine(58,0);
	};
	void weaponList() {
		string wizardWeapons[8] = { "Club", "Dagger", "Quarterstaff", "Handaxe", "Spear", "Light crossbow", "Sling", "Darts" };
		while (!(weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8)) {
			cout << "\nSelect a Weapon:" << endl;
			for (int i = 0; i < 8; i++) {
				cout << i + 1 << "-" << wizardWeapons[i] << "\n";
			}
			cin >> weaponNum;
			if (weaponNum == 1 || weaponNum == 2 || weaponNum == 3 || weaponNum == 4 || weaponNum == 5 || weaponNum == 6 || weaponNum == 7 || weaponNum == 8) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		weapon = wizardWeapons[weaponNum - 1];
		cout << "Your weapon is a: " << weapon << endl;
	};
	void armorList() {
		while (!(armorNum == 1)) {
			cout << "\nSelect Armor:\n"
				"1-No Armor" << endl;
			cin >> armorNum;
			if (armorNum == 1) {
				break;
			}
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		armor = "No Armor";
		cout << "You have: " << armor << endl;
	};
	void skillList() {
		choices = 2;
		avaliableSkills = 6;
		string wizardSkills[6] = { "Arcana", "History", "Insight", "Investigation", "Medicine", "Religion" };
		while (chosen < choices) {
			chosenSkill = 0;
			while (!(chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6)) {
				cout << "\nChoose " << choices - chosen << " skill(s) to be proficent in:" << endl;
				for (int i = 0; i < avaliableSkills; i++) {
					cout << i + 1 << "-" << wizardSkills[i] << "\n";
				}
				cin >> chosenSkill;
				if (chosenSkill == 1 || chosenSkill == 2 || chosenSkill == 3 || chosenSkill == 4 || chosenSkill == 5 || chosenSkill == 6) {
					break;
				}
				else {
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			repeat = false;
			for (int j = 0; j < 4; j++) {
				if (proSkills[j] == wizardSkills[chosenSkill - 1]) {
					cout << "You have already chosen " << wizardSkills[chosenSkill-1];
					repeat = true;
					break;
				}
			}
			if (repeat == true) {
				continue;
			}
			else {
				proSkills[chosen] = wizardSkills[chosenSkill - 1];
				chosen += 1;
			}
		}
		cout << "You are now proficent in:" << endl;
		for (int i = 0; i < choices; i++) {
			cout << proSkills[i] << endl;
		}
	}
};
//RACES
class Tiefling {
public:
	void displayDes() {
		//method to display the description of the race
		cout << "\nYou have chosen the Tiefling race.\n"
			"You are:" << endl;
		readTwoLines(75, 76,0);
	};
	void raceAbilityDes() {
		//method to display the racial abilities of the race
		cout << "\nYou have these abilities" << endl;
		readTwoLines(81, 82,0);
	};
};
class Elf {
public:
	void displayDes() {
		cout << "\nYou have chosen the Elf race.\n"
			"You:" << endl;
		readOneLine(87,0);
	};
	void raceAbilityDes() {
		cout << "\nYou have these abilities" << endl;
		readTwoLines(91, 92,0);
	};
};
class Dwarf {
public:
	void displayDes() {
		cout << "\nYou have chosen the Dwarf race.\n"
			"You are:" << endl;
		readOneLine(97,0);
	};
	void raceAbilityDes() {
		cout << "\nYou have these abilities" << endl;
		readOneLine(102,0);
	};
};
class Dragonborn {
public:
	void displayDes() {
		cout << "\nYou have chosen the Dragonborn race.\n"
			"You:" << endl;
		readOneLine(107,0);
	};
	void raceAbilityDes() {
		cout << "\nYou have these abilities" << endl;
		readTwoLines(112, 113,0);
	};
};
class Human {
public:
	void displayDes() {
		cout << "\nYou have chosen the Human race.\n"
			"You:" << endl;
		readTwoLines(118, 119,0);
	};
	void raceAbilityDes() {
		cout << "\nYou have these abilities" << endl;
		readOneLine(123,0);
	};
};
class Gnome {
public:
	void displayDes() {
		cout << "\nYou have chosen the Gnome race.\n"
			"You:" << endl;
		readOneLine(128,0);
	};
	void raceAbilityDes() {
		cout << "\nYou have these abilities" << endl;
		readTwoLines(132, 133, 0);
	};
};



int main()
{
	//loop for main menu
	while (!(play == 1 || play == 2)) {
		cout << "DnD CREATOR-INATOR\n"	//menu options
			"1-Create Character\n"
			"2-Exit\n";
		cin >> play;	//input menu option
		if (play == 1 || play == 2) {	//checks if valid menu option
			break;
		}
		else {	//gets rid of erros
			cout << "Invalid Input\n" << endl;
			cin.clear();
			cin.ignore(150, '\n');
		}
	}
	//loop for game
	while (play == 1) {
		//Race selection menu
		while (raceNum != 1 && raceNum != 2 && raceNum != 3 && raceNum != 4 && raceNum != 5 && raceNum != 6) {
			cout << "\nSelect a race:\n"	//displays race menu
				"1-Tiefling\n"
				"2-Elf\n"
				"3-Dwarf\n"
				"4-Dragonborn\n"
				"5-Human\n"
				"6-Gnome\n"
				"7-See Race descriptions\n";
			cin >> raceNum;	//asks for race input
			//checks if chosen race is valid
			if (raceNum == 1 || raceNum == 2 || raceNum == 3 || raceNum == 4 || raceNum == 5 || raceNum == 6) {
				break;
			}
			else if (raceNum == 7) {	//if the last option is chosen prints teh entire description for every race
				displayDes(70, 134);
				continue;
			}
			else {	//checks for errors
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}

		}
		//determines chosen race and creates obj. then display the race's description and ability
		switch (raceNum) {
		case 1:
			Tiefling tieRace;
			tieRace.displayDes();
			tieRace.raceAbilityDes();
			break;
		case 2:
			Elf elfRace;
			elfRace.displayDes();
			elfRace.raceAbilityDes();
			break;
		case 3:
			Dwarf dwaRace;
			dwaRace.displayDes();
			dwaRace.raceAbilityDes();
			break;
		case 4:
			Dragonborn draRace;
			draRace.displayDes();
			draRace.raceAbilityDes();
			break;
		case 5:
			Human humRace;
			humRace.displayDes();
			humRace.raceAbilityDes();
			break;
		case 6:
			Gnome gnoRace;
			gnoRace.displayDes();
			gnoRace.raceAbilityDes();
			break;
		}

		//class menu selection
		while (classNum != 1 && classNum != 2 && classNum != 3 && classNum != 4 && classNum != 5 && classNum != 6) {
			//loops class menu until vaid input
			cout << "\nSelect a class:\n"
				"1-Rogue\n"
				"2-Warlock\n"
				"3-Druid\n"
				"4-Bard\n"
				"5-Cleric\n"
				"6-Wizard\n"
				"7-See Class descriptions\n";
			cin >> classNum;	//class input
			//checks input is valid
			if (classNum == 1 || classNum == 2 || classNum == 3 || classNum == 4 || classNum == 5 || classNum == 6) {
				break;
			}
			else if (classNum == 7) {	//if last menu option chosen displays dexcriptions for every class
				displayDes(0, 66);
				continue;
			}//otherwise gets rid of errors
			else {
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		//Based upon chosen class
		switch (classNum) {
		case 1:
			Rogue rogClass;				//creates class object
			rogClass.displayDes();		//displays class descrption
			rogClass.weaponList();		//allows user to select weapon from class list
			rogClass.armorList();		//allows user to select armor from class list
			rogClass.skillList();		//allows user to choice which skills to be profiecent in
			rollHealth(8);				//rolls health based upon class
			break;
		case 2:
			Warlock warClass;
			warClass.displayDes();
			warClass.weaponList();
			spells();
			warClass.armorList();
			warClass.skillList();
			rollHealth(8);
			break;
		case 3:
			Druid druClass;
			druClass.displayDes();
			druClass.weaponList();
			spells();		//indicated spells for spellcasters
			druClass.armorList();
			druClass.skillList();
			rollHealth(8);
			break;
		case 4:
			Bard barClass;
			barClass.displayDes();
			barClass.weaponList();
			spells();
			barClass.armorList();
			barClass.skillList();
			rollHealth(8);
			break;
		case 5:
			Cleric cleClass;
			cleClass.displayDes();
			cleClass.weaponList();
			spells();
			cleClass.armorList();
			cleClass.skillList();
			rollHealth(8);
			break;
		case 6:
			Wizard wizClass;
			wizClass.displayDes();
			wizClass.weaponList();
			spells();
			wizClass.armorList();
			wizClass.skillList();
			rollHealth(6);
			break;
		}

		//Rolling Statistics
		cout << "\nTime to roll you stats!" << endl;
		while (skillValue[0] == 0 || skillValue[1] == 0 || skillValue[2] == 0 || skillValue[3] == 0 || skillValue[4] == 0 || skillValue[5] == 0) {
			//loops skill selection until all ability skills a=have a value
			int roll = rand() % 20 + 1;	//re-rolls a d20
			cout << "You rolled: " << roll << endl;		//prints roll
			if (roll < 10) {	//reassigns roll if below 10
				cout << "Your roll has been changed to 10." << endl;	//informs user
				roll = 10;
			}
			int rollAssign = 0;	//resets roll assign
			while (!(rollAssign == 1 || rollAssign == 2 || rollAssign == 3 || rollAssign == 4 || rollAssign == 5 || rollAssign == 6)) {
				//loops through menu until value is assigned to a new ability skill
				const int max = 6;	
				cout << "Which ability would you like to assign " << roll << " to?" << endl;
				for (int k = 0; k < max;) {	//prints all ability skills
					cout << k + 1 << "-" << skills[k] << endl;
					k++;
				};
				cin >> rollAssign;	//asks for what skill to assign to
				//checks if input is valid
				if (rollAssign == 1 || rollAssign == 2 || rollAssign == 3 || rollAssign == 4 || rollAssign == 5 || rollAssign == 6) {
					continue;
				}
				else {	//gets rid of errors
					cout << "Invalid Input\n" << endl;
					cin.clear();
					cin.ignore(150, '\n');
				}
			}
			if (skillValue[rollAssign - 1] == 0) {	//assigns the roll to the stat if it was zero
				skillValue[rollAssign - 1] = roll;
			}
			else {	//if stat not zero the informs user what values are still zero
				cout << "You have already assigned a value to " << skills[rollAssign - 1] << endl;
				cout << "These don't have values:";
				for (int j = 0; j < 5; j++) {	//loops through looking for zero values
					if (skillValue[j] == 0) {
						cout << skills[j] << ", ";	//prints ability skill name if value is zero
					}
				}
				cout << endl;
			}

		}

		//Adding modifier, each race has modifier to some ability skills
		//adds the modifier to the correct skill for the class
		cout << "\nWith modifiers your stats are:" << endl;
		switch (raceNum) {	//adds modifers based upon chosen race
			case 1:		//tiefling
				skillValue[5] += 2;		//ex: if tiefling then +2 charisma and +1 intelligence
				skillValue[3] += 1;
				break;
			case 2:		//elf
				skillValue[1] += 2;
				break;
			case 3:		//dwarf
				skillValue[2] += 2;
				break;
			case 4:		//dragonborn
				skillValue[0] += 2;
				skillValue[5] += 1;
				break;
			case 5:		//humnan
				skillValue[0] += 1;
				skillValue[1] += 1;
				skillValue[2] += 1;
				skillValue[3] += 1;
				skillValue[4] += 1;
				skillValue[5] += 1;
				break;
			case 6:		//gnome
				skillValue[3] += 2;
				break;
			}
		//prints Stats from 2 arrays
		for (int i = 0; i <= 5; i++) {		
				cout << skills[i];
				if (i == 4) {
					cout << "\t\t";
				}
				else {
					cout << "\t";
				}
				cout << skillValue[i] << endl;
			}

		//Name selection
		string name;
		cout << "What would you like to name your character?";
		cin >> name;
		cout << "Your name is now: " << name << endl;


		//Create Chracter sheet
		//File writing to produce character sheet to the file "CharacterSheet"
		int modifier = 0;
		MySheet << "DnD Creator_Inator Character Sheet" << endl;
		MySheet << "------------------------------------------------------------------------------------------------------" << endl;
		MySheet << "Ability\t\t" << "Value" << "\tModifier" << endl;
		for (int i = 0; i <= 5; i++) {			//displays stats
				MySheet << skills[i];
				if (i == 4) {
					MySheet << "\t\t";
				}
				else {
					MySheet << "\t";
				}
				MySheet << skillValue[i];	//displays ability skill
				//determine ability skill modifier based upon value of ability skill
				if (skillValue[i] >= 10 && skillValue[i] <= 11) {
					modifier = 0;
				}
				else if (skillValue[i] >= 12 && skillValue[i] <= 13) {
					modifier = 1;
				}
				else if (skillValue[i] >= 14 && skillValue[i] <= 15) {
					modifier = 2;
				}
				else if (skillValue[i] >= 16 && skillValue[i] <= 17) {
					modifier = 3;
				}
				else if (skillValue[i] >= 18 && skillValue[i] <= 19) {
					modifier = 1;
				}
				else {
					modifier = 5;
				}
				MySheet << "\t" << modifier << endl;
				//assigns the modifier to specifc ability skill values based
				switch (i + 1) {
				case 1:
					strMod = modifier;
					break;
				case 2:
					dexMod = modifier;
					break;
				case 3:
					conMod = modifier;
					break;
				case 4:
					intMod = modifier;
					break;
				case 5:
					wisMod = modifier;
					break;
				case 6:
					chaMod = modifier;
					break;
				}
			}
		MySheet << "Profiency Bonus: 2";	//prints profiency bonus
		//prints Saving throws based upon class chosen
		switch (classNum) {
			case 1:
				readOneLine(10, 1);
				break;
			case 2:
				readOneLine(21, 1);
				break;
			case 3:
				readOneLine(32, 1);
				break;
			case 4:
				readOneLine(42, 1);
				break;
			case 5:
				readOneLine(53, 1);
				break;
			case 6:
				readOneLine(64, 1);
				break;
			}
		MySheet << "------------------------------------------------------------------------------------------------------" << endl;
		MySheet << "Health: " << healthRoll + conMod << endl;	//orints health
		MySheet << "Name: " << name << endl;					//prints name
		MySheet << "Class: " << classes[classNum] << endl;		//prints class name
		MySheet << "Race: " << races[raceNum] << endl;			//prints race
		MySheet << "Racial Abilities: " << endl;				//prints racial ability
		// prints racial ability based upon chosen race
		switch (raceNum) {
			case 1:
				readTwoLines(81, 82, 1);
				break;
			case 2:
				readTwoLines(91, 92, 1);
				break;
			case 3:
				readTwoLines(101, 102, 1);
				break;
			case 4:
				readTwoLines(112, 113, 1);
				break;
			case 5:
				readOneLine(123, 1);
				break;
			case 6:
				readTwoLines(132, 133, 1);
				break;
			}
		MySheet << "Armor Type: " << armor << endl;	//prints armor
		MySheet << "Weapon: " << weapon << endl;	//prints weapon
		MySheet << "Spells: Check with DM for guide." << endl;
		MySheet << "------------------------------------------------------------------------------------------------------" << endl;
		//Lists 18 skills each skill has a modifier next to it based upon which of the 6 ability skills modifier it would belong to in dnd
		MySheet << "Skill Checks with modifiers:" << endl;
		MySheet << strMod;	
		for (int i = 0; i < 18; i++) {
				MySheet << minorSkills[i] << "   ";
				if (i == 0) {
					MySheet << strMod;
				}
				else if (i >= 1 && i <= 3) {
					MySheet << dexMod;
				}
				else if (i >= 4 && i <= 8) {
					MySheet << intMod;
				}
				else if (i >= 9 && i <= 13) {
					MySheet << wisMod;
				}
				else if (i >= 14 && i <= 17) {
					MySheet << chaMod;
				}
				MySheet << endl;
			}
		MySheet << "Proficent in: ";
		for (int i = 0; i < 4; i++) {	//prints profiencies in skills
				MySheet << proSkills[i] << "   ";
			}
		cout << endl;
		MySheet.close();

		//end screen displays result and tells user to exit
		exitGame = 0;
		while (exitGame !=1) {
			//loops end menu if user inputs wrong thing
			cout << "\n\n Your character sheet is created in the CharacterSheet.txt file." << endl;
			cout << "1-Exit" << endl;
			cin >>exitGame;
			if (exitGame == 1) {
				break;
			}
			else {	//gets rid of errors
				cout << "Invalid Input\n" << endl;
				cin.clear();
				cin.ignore(150, '\n');
			}
		}
		if (exitGame == 1) {
			break;
		}
	}
}


